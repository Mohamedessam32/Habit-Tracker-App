String? userName;
String? userEmial;
String? token;
bool? isNotificationEnabled;
