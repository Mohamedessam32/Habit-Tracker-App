package com.example.habit_track

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
